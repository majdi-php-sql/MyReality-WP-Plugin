<?php
// Fetch payment data for display
global $wpdb;
$payments = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}myrealty_payments");

?>

<h1>Payments</h1>

<h2>Payment Records</h2>
<table class="wp-list-table widefat fixed striped">
    <thead>
        <tr>
            <th>ID</th>
            <th>Property ID</th>
            <th>Tenant</th>
            <th>Amount</th>
            <th>Due Date</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($payments as $payment) { ?>
            <tr>
                <td><?php echo $payment->id; ?></td>
                <td><?php echo $payment->property_id; ?></td>
                <td><?php echo $payment->tenant_id; // Fetch tenant name ?></td>
                <td><?php echo $payment->amount; ?></td>
                <td><?php echo $payment->due_date; ?></td>
                <td><?php echo $payment->status; ?></td>
                <td>
                    <!-- Add Edit and Delete Actions -->
                </td>
            </tr>
        <?php } ?>
    </tbody>
</table>
