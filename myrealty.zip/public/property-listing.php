<h1>Available Properties</h1>
<p>Browse our available properties.</p>
