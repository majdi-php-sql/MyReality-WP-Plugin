<?php
// Fetch existing agents for display
global $wpdb;
$agents = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}myrealty_agents");

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_agent'])) {
    // Add a new agent
    $wpdb->insert(
        "{$wpdb->prefix}myrealty_agents",
        array(
            'name' => sanitize_text_field($_POST['name']),
            'landline' => sanitize_text_field($_POST['landline']),
            'mobile' => sanitize_text_field($_POST['mobile']),
            'agent_image' => esc_url_raw($_POST['agent_image'])
        )
    );
    echo '<div class="notice notice-success"><p>Agent added successfully!</p></div>';
}
?>

<h1>Manage Agents</h1>
<form method="post">
    <h2>Add New Agent</h2>
    <label for="name">Name</label>
    <input type="text" name="name" id="name" required>

    <label for="landline">Landline</label>
    <input type="text" name="landline" id="landline" required>

    <label for="mobile">Mobile</label>
    <input type="text" name="mobile" id="mobile" required>

    <label for="agent_image">Agent Image URL</label>
    <input type="url" name="agent_image" id="agent_image" required>

    <input type="submit" name="add_agent" value="Add Agent" class="button button-primary">
</form>

<h2>Existing Agents</h2>
<table class="wp-list-table widefat fixed striped">
    <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Landline</th>
            <th>Mobile</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($agents as $agent) { ?>
            <tr>
                <td><?php echo $agent->id; ?></td>
                <td><?php echo $agent->name; ?></td>
                <td><?php echo $agent->landline; ?></td>
                <td><?php echo $agent->mobile; ?></td>
                <td>
                    <!-- Add Edit and Delete Actions -->
                </td>
            </tr>
        <?php } ?>
    </tbody>
</table>
