<h1>MyRealty Dashboard</h1>
<p>Welcome to the MyRealty management system.</p>
