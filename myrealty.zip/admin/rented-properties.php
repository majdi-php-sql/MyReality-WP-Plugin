<?php
// Fetch rented properties for display
global $wpdb;
$rented_properties = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}myrealty_properties WHERE status = 'rented'");

?>

<h1>Rented Properties</h1>

<h2>Rented Properties List</h2>
<table class="wp-list-table widefat fixed striped">
    <thead>
        <tr>
            <th>ID</th>
            <th>Type</th>
            <th>Location</th>
            <th>Agent</th>
            <th>Tenant</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($rented_properties as $property) { ?>
            <tr>
                <td><?php echo $property->id; ?></td>
                <td><?php echo $property->type; ?></td>
                <td><?php echo $property->location; ?></td>
                <td><?php echo $property->agent_id; // Fetch agent name ?></td>
                <td>
                    <!-- Fetch tenant name -->
                </td>
                <td>
                    <!-- Add View Details and Delete Actions -->
                </td>
            </tr>
        <?php } ?>
    </tbody>
</table>
