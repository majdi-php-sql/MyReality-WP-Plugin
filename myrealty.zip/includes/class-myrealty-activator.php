<?php

class MyRealty_Activator {
    public static function activate() {
        // Create necessary database tables
        MyRealty_DB::create_tables();
    }
}
