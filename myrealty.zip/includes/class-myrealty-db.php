<?php

class MyRealty_DB {
    public static function create_tables() {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE {$wpdb->prefix}myrealty_properties (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            type varchar(255) NOT NULL,
            location varchar(255) NOT NULL,
            address text NOT NULL,
            bedrooms int NOT NULL,
            bathrooms int NOT NULL,
            area varchar(255) NOT NULL,
            features text NOT NULL,
            rental_type varchar(255) NOT NULL,
            rental_cost decimal(10,2) NOT NULL,
            agent_id mediumint(9) NOT NULL,
            status varchar(50) NOT NULL,
            description text NOT NULL,
            images text NOT NULL,
            video_url varchar(255) NOT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
}
