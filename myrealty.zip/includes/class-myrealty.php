<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class MyRealty {

    public static function init() {
        add_action('admin_menu', array(__CLASS__, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array(__CLASS__, 'enqueue_admin_styles'));
    }

    public static function add_admin_menu() {
        add_menu_page(
            'MyRealty Plugin',
            'MyRealty',
            'manage_options',
            'myrealty',
            array(__CLASS__, 'property_management_page'),
            'dashicons-admin-home'
        );

        add_submenu_page(
            'myrealty',
            'Property Management',
            'Properties',
            'manage_options',
            'myrealty',
            array(__CLASS__, 'property_management_page')
        );

        add_submenu_page(
            'myrealty',
            'Agent Management',
            'Agents',
            'manage_options',
            'myrealty-agents',
            array(__CLASS__, 'agent_management_page')
        );

        add_submenu_page(
            'myrealty',
            'Rented Properties',
            'Rented Properties',
            'manage_options',
            'myrealty-rented',
            array(__CLASS__, 'rented_properties_page')
        );

        add_submenu_page(
            'myrealty',
            'Payments',
            'Payments',
            'manage_options',
            'myrealty-payments',
            array(__CLASS__, 'payments_page')
        );

        add_submenu_page(
            'myrealty',
            'Reports',
            'Reports',
            'manage_options',
            'myrealty-reports',
            array(__CLASS__, 'reports_page')
        );
    }

    public static function enqueue_admin_styles() {
        wp_enqueue_style('myrealty-admin', MYREALTY_PLUGIN_URL . 'admin/styles.css');
    }

    public static function property_management_page() {
        include MYREALTY_PLUGIN_DIR . 'admin/property-management.php';
    }

    public static function agent_management_page() {
        include MYREALTY_PLUGIN_DIR . 'admin/agent-management.php';
    }

    public static function rented_properties_page() {
        include MYREALTY_PLUGIN_DIR . 'admin/rented-properties.php';
    }

    public static function payments_page() {
        include MYREALTY_PLUGIN_DIR . 'admin/payments.php';
    }

    public static function reports_page() {
        include MYREALTY_PLUGIN_DIR . 'admin/reports.php';
    }
}
