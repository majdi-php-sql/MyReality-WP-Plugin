<h1>Property Details</h1>
<p>Details about the selected property.</p>
