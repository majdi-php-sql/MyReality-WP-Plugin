<?php

class MyRealty_Deactivator {
    public static function deactivate() {
        // Clean up actions if needed
    }
}
