<?php
/*
Plugin Name: MyRealty
Description: A comprehensive real estate management plugin for MyRealty.
Version: 1.0
Author: Majdi M. S. Awad
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Define plugin directory and URL.
define('MYREALTY_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('MYREALTY_PLUGIN_URL', plugin_dir_url(__FILE__));

// Include the main class file.
require_once MYREALTY_PLUGIN_DIR . 'includes/class-myrealty.php';

// Register activation hook to create database tables.
register_activation_hook(__FILE__, 'myrealty_create_tables');

function myrealty_create_tables() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "
    CREATE TABLE {$wpdb->prefix}myrealty_properties (
        id INT AUTO_INCREMENT PRIMARY KEY,
        type VARCHAR(50),
        location VARCHAR(255),
        address VARCHAR(255),
        bedrooms INT,
        bathrooms INT,
        area VARCHAR(100),
        features TEXT,
        rental_type VARCHAR(50),
        rental_cost FLOAT,
        agent_id INT,
        status VARCHAR(50),
        description TEXT,
        images TEXT,
        video_url VARCHAR(255)
    ) $charset_collate;

    CREATE TABLE {$wpdb->prefix}myrealty_agents (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100),
        landline VARCHAR(50),
        mobile VARCHAR(50),
        agent_image VARCHAR(255)
    ) $charset_collate;

    CREATE TABLE {$wpdb->prefix}myrealty_payments (
        id INT AUTO_INCREMENT PRIMARY KEY,
        property_id INT,
        tenant_id INT,
        amount FLOAT,
        due_date DATE,
        status VARCHAR(50)
    ) $charset_collate;
    ";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// Initialize the plugin.
MyRealty::init();
