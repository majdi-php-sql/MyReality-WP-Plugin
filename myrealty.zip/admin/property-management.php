<?php
// Fetch existing properties for display
global $wpdb;
$properties = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}myrealty_properties");

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_property'])) {
    // Add a new property
    $wpdb->insert(
        "{$wpdb->prefix}myrealty_properties",
        array(
            'type' => sanitize_text_field($_POST['type']),
            'location' => sanitize_text_field($_POST['location']),
            'address' => sanitize_text_field($_POST['address']),
            'bedrooms' => intval($_POST['bedrooms']),
            'bathrooms' => intval($_POST['bathrooms']),
            'area' => sanitize_text_field($_POST['area']),
            'features' => sanitize_text_field(implode(',', $_POST['features'])),
            'rental_type' => sanitize_text_field($_POST['rental_type']),
            'rental_cost' => floatval($_POST['rental_cost']),
            'agent_id' => intval($_POST['agent_id']),
            'status' => sanitize_text_field($_POST['status']),
            'description' => sanitize_textarea_field($_POST['description']),
            'images' => sanitize_text_field(implode(',', $_POST['images'])),
            'video_url' => esc_url_raw($_POST['video_url'])
        )
    );
    echo '<div class="notice notice-success"><p>Property added successfully!</p></div>';
}
?>

<h1>Manage Properties</h1>
<form method="post">
    <h2>Add New Property</h2>
    <label for="type">Property Type</label>
    <select name="type" id="type">
        <option value="apartment">Apartment</option>
        <option value="villa">Villa</option>
        <option value="house">House</option>
        <!-- Add more types as needed -->
    </select>

    <label for="location">Location</label>
    <input type="text" name="location" id="location" required>

    <label for="address">Address</label>
    <input type="text" name="address" id="address" required>

    <label for="bedrooms">Number of Bedrooms</label>
    <input type="number" name="bedrooms" id="bedrooms" required>

    <label for="bathrooms">Number of Bathrooms</label>
    <input type="number" name="bathrooms" id="bathrooms" required>

    <label for="area">Area</label>
    <input type="text" name="area" id="area" required>

    <label for="features">Features</label>
    <input type="checkbox" name="features[]" value="TV"> TV
    <input type="checkbox" name="features[]" value="balcony"> Balcony
    <input type="checkbox" name="features[]" value="parking"> Parking
    <!-- Add more features as needed -->

    <label for="rental_type">Rental Type</label>
    <select name="rental_type" id="rental_type">
        <option value="monthly">Monthly</option>
        <option value="annual">Annual</option>
    </select>

    <label for="rental_cost">Rental Cost</label>
    <input type="number" name="rental_cost" id="rental_cost" required>

    <label for="agent_id">Agent</label>
    <select name="agent_id" id="agent_id">
        <?php
        $agents = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}myrealty_agents");
        foreach ($agents as $agent) {
            echo "<option value='{$agent->id}'>{$agent->name}</option>";
        }
        ?>
    </select>

    <label for="status">Status</label>
    <select name="status" id="status">
        <option value="available">Available</option>
        <option value="rented">Rented</option>
    </select>

    <label for="description">Description</label>
    <textarea name="description" id="description"></textarea>

    <label for="images">Images (URLs, comma-separated)</label>
    <input type="text" name="images" id="images">

    <label for="video_url">YouTube Video URL</label>
    <input type="url" name="video_url" id="video_url">

    <input type="submit" name="add_property" value="Add Property" class="button button-primary">
</form>

<h2>Existing Properties</h2>
<table class="wp-list-table widefat fixed striped">
    <thead>
        <tr>
            <th>ID</th>
            <th>Type</th>
            <th>Location</th>
            <th>Agent</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($properties as $property) { ?>
            <tr>
                <td><?php echo $property->id; ?></td>
                <td><?php echo $property->type; ?></td>
                <td><?php echo $property->location; ?></td>
                <td><?php echo $property->agent_id; // Fetch agent name ?></td>
                <td><?php echo $property->status; ?></td>
                <td>
                    <!-- Add Edit and Delete Actions -->
                </td>
            </tr>
        <?php } ?>
    </tbody>
</table>
